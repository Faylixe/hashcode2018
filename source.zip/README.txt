Solution created using fv/metropolis.py with python
